import { Phone, MapPin } from 'lucide-react'
import { site } from '@/lib/site'

const quick = [
  { label: 'Student Login', href: '#login' },
  { label: 'Parent Login', href: '#login' },
  { label: 'Staff Attendance', href: '#staff-portal' },
]

export function TopBar() {
  return (
    <div className="bg-primary text-primary-foreground text-xs sm:text-sm">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-2 sm:px-6">
        <div className="flex items-center gap-5">
          <a href={`tel:${site.phone}`} className="flex items-center gap-2 transition-colors hover:text-accent">
            <Phone className="size-3.5 text-accent" aria-hidden="true" />
            <span>{site.phoneDisplay}</span>
          </a>
          <span className="hidden items-center gap-2 md:flex">
            <MapPin className="size-3.5 text-accent" aria-hidden="true" />
            {site.address}
          </span>
        </div>
        <nav aria-label="Portal links" className="flex items-center gap-3 sm:gap-5">
          {quick.map((q, i) => (
            <a
              key={q.label}
              href={q.href}
              className={`transition-colors hover:text-accent ${i === 1 ? 'hidden sm:inline' : ''}`}
            >
              {q.label}
            </a>
          ))}
        </nav>
      </div>
    </div>
  )
}
