import Image from 'next/image'
import { Quote } from 'lucide-react'

export function DirectorMessage() {
  return (
    <section aria-labelledby="director-title" className="bg-secondary px-4 py-24 sm:px-6">
      <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-[2fr_3fr]">
        <div className="relative mx-auto w-full max-w-sm">
          <div className="absolute -bottom-4 -right-4 h-full w-full rounded-3xl bg-accent" aria-hidden="true" />
          <div className="relative aspect-[4/5] overflow-hidden rounded-3xl shadow-xl">
            <Image
              src="/images/director.png"
              alt="Daulataram Saran, Managing Director"
              fill
              sizes="(min-width: 1024px) 384px, 90vw"
              className="object-cover"
            />
          </div>
        </div>
        <div>
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.22em] text-primary/70">
            <span className="mr-2 inline-block h-px w-6 bg-accent align-middle" aria-hidden="true" />
            {"Director's Message"}
          </p>
          <h2 id="director-title" className="text-3xl font-bold leading-tight text-primary sm:text-4xl">
            Message from Managing Director
          </h2>
          <Quote className="mt-8 size-10 text-accent" aria-hidden="true" />
          <blockquote className="mt-4 flex flex-col gap-4 text-base leading-relaxed text-foreground/85 sm:text-lg">
            <p>
              At Kamdhenu, we believe education is not only about marks; it is about building character. Our mission is
              to blend modern, scientific education with timeless Indian values of discipline, respect and service.
            </p>
            <p>
              Every child who walks through our gates is nurtured like family, guided to dream big and equipped to
              achieve it with integrity. Together with parents, we shape citizens who will make Nagaur and the nation
              proud.
            </p>
          </blockquote>
          <div className="mt-8 border-l-4 border-accent pl-4">
            <p className="font-serif text-xl font-bold text-primary">Daulataram Saran</p>
            <p className="text-sm text-muted-foreground">M.Sc. Chemistry, B.Ed. · 16 Years Experience</p>
          </div>
        </div>
      </div>
    </section>
  )
}
