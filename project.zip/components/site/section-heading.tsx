import { cn } from '@/lib/utils'

export function SectionHeading({
  id,
  eyebrow,
  title,
  description,
  align = 'center',
  tone = 'light',
}: {
  id: string
  eyebrow: string
  title: string
  description?: string
  align?: 'center' | 'left'
  tone?: 'light' | 'dark'
}) {
  return (
    <div className={cn('mb-12 max-w-2xl', align === 'center' && 'mx-auto text-center')}>
      <p
        className={cn(
          'mb-3 text-xs font-semibold uppercase tracking-[0.22em]',
          tone === 'dark' ? 'text-accent' : 'text-primary/70',
        )}
      >
        <span className="mr-2 inline-block h-px w-6 bg-accent align-middle" aria-hidden="true" />
        {eyebrow}
      </p>
      <h2
        id={id}
        className={cn(
          'text-3xl font-bold leading-tight sm:text-4xl',
          tone === 'dark' ? 'text-primary-foreground' : 'text-primary',
        )}
      >
        {title}
      </h2>
      {description && (
        <p
          className={cn(
            'mt-4 leading-relaxed text-pretty',
            tone === 'dark' ? 'text-primary-foreground/80' : 'text-muted-foreground',
          )}
        >
          {description}
        </p>
      )}
    </div>
  )
}
