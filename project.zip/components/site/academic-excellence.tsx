import Image from 'next/image'
import { MapPinCheck, Fingerprint, ShieldCheck, Microscope, LogIn } from 'lucide-react'
import { SectionHeading } from './section-heading'

export function AcademicExcellence() {
  return (
    <section id="about" aria-labelledby="excellence-title" className="px-4 py-24 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          id="excellence-title"
          eyebrow="Academic Excellence"
          title="Built for Learning, Designed for Care"
          description="World-class facilities, safe residences and modern systems that keep our campus running with discipline and transparency."
        />
        <div className="grid gap-6 lg:grid-cols-3">
          <article className="group overflow-hidden rounded-3xl border border-border bg-card shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10">
            <div className="relative aspect-[16/10] overflow-hidden">
              <Image
                src="/images/science-lab.png"
                alt="Students performing experiments in a science lab"
                fill
                sizes="(min-width: 1024px) 33vw, 100vw"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            <div className="p-7">
              <div className="mb-3 flex items-center gap-2 text-primary">
                <Microscope className="size-5" aria-hidden="true" />
                <span className="text-xs font-semibold uppercase tracking-wider">Science</span>
              </div>
              <h3 className="text-2xl font-bold text-primary">Modern Science Labs</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                Fully equipped Physics, Chemistry and Biology labs where students learn by doing, building a strong
                foundation for NEET, JEE and Agriculture careers.
              </p>
            </div>
          </article>

          <article className="group overflow-hidden rounded-3xl border border-border bg-card shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10">
            <div className="relative aspect-[16/10] overflow-hidden">
              <Image
                src="/images/hostel.png"
                alt="Students studying together in the hostel courtyard"
                fill
                sizes="(min-width: 1024px) 33vw, 100vw"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            <div className="p-7">
              <div className="mb-3 flex items-center gap-2 text-primary">
                <ShieldCheck className="size-5" aria-hidden="true" />
                <span className="text-xs font-semibold uppercase tracking-wider">Residential</span>
              </div>
              <h3 className="text-2xl font-bold text-primary">Safe Hostels</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                Separate, secure hostels for boys and girls with 24x7 wardens, CCTV, nutritious home-style meals and
                supervised night study.
              </p>
            </div>
          </article>

          <article
            id="staff-portal"
            className="relative flex scroll-mt-28 flex-col overflow-hidden rounded-3xl bg-primary p-8 text-primary-foreground shadow-xl shadow-primary/20 transition-all hover:-translate-y-1"
          >
            <div
              className="pointer-events-none absolute -right-16 -top-16 size-56 rounded-full bg-accent/15 blur-2xl"
              aria-hidden="true"
            />
            <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-primary">
              For Teachers &amp; Staff
            </span>
            <span className="mt-6 flex size-16 items-center justify-center rounded-2xl border border-accent/40 bg-accent/10 text-accent">
              <MapPinCheck className="size-8" aria-hidden="true" />
            </span>
            <h3 className="mt-6 text-2xl font-bold">Staff GPS Attendance Portal</h3>
            <p className="mt-3 text-sm leading-relaxed text-primary-foreground/80">
              Mark your daily attendance securely from campus. Location is verified using GPS so every check-in is
              accurate and transparent.
            </p>
            <ul className="mt-6 flex flex-col gap-3 text-sm text-primary-foreground/90">
              <li className="flex items-center gap-3">
                <MapPinCheck className="size-4 text-accent" aria-hidden="true" />
                Geo-fenced campus check-in
              </li>
              <li className="flex items-center gap-3">
                <Fingerprint className="size-4 text-accent" aria-hidden="true" />
                Secure, personal staff login
              </li>
            </ul>
            <div className="flex-1" />
            <a
              href="#login"
              className="mt-8 inline-flex items-center justify-center gap-2 rounded-full bg-accent px-6 py-3.5 text-sm font-semibold text-primary transition-all hover:shadow-lg hover:shadow-accent/20"
            >
              <LogIn className="size-4" aria-hidden="true" />
              Staff Login
            </a>
          </article>
        </div>
      </div>
    </section>
  )
}
