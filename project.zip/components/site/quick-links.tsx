import { FlaskConical, School, Stethoscope, BedDouble, Bot, Fingerprint } from 'lucide-react'

const links = [
  { icon: FlaskConical, label: 'Kamdhenu Science School', sub: 'School & Campus', href: '#institutions' },
  { icon: School, label: 'Kamdhenu English School', sub: 'Play Group – 12th', href: '#institutions' },
  { icon: Stethoscope, label: 'Medical Academy', sub: 'Coaching', href: '#institutions' },
  { icon: BedDouble, label: 'Our Hostels', sub: 'Gurukul System', href: '#hostel' },
  { icon: Bot, label: 'AI Chatbot', sub: 'Instant Answers', href: '#chatbot' },
  { icon: Fingerprint, label: 'Staff Portal', sub: 'GPS Attendance', href: '#staff-portal' },
]

export function QuickLinks() {
  return (
    <section aria-label="Quick links" className="relative z-10 -mt-16 px-4 sm:px-6">
      <div className="mx-auto max-w-7xl rounded-3xl border border-border bg-card p-4 shadow-xl shadow-primary/5 sm:p-6">
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {links.map((l) => (
            <li key={l.label}>
              <a
                href={l.href}
                className="group flex h-full flex-col items-center gap-3 rounded-2xl p-4 text-center transition-all hover:-translate-y-1 hover:bg-secondary"
              >
                <span className="flex size-14 items-center justify-center rounded-2xl bg-primary text-accent shadow-md shadow-primary/20 transition-colors group-hover:bg-accent group-hover:text-primary">
                  <l.icon className="size-6" aria-hidden="true" />
                </span>
                <span className="text-sm font-semibold leading-snug text-primary">{l.label}</span>
                <span className="-mt-2 text-xs text-muted-foreground">{l.sub}</span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
