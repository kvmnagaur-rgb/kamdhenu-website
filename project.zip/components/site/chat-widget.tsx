'use client'

import { useState } from 'react'
import { Bot, X, MessageCircle } from 'lucide-react'
import { site } from '@/lib/site'

const faqs = [
  {
    q: 'What courses do you offer?',
    a: 'We run Kamdhenu Science School (6th–12th), Kamdhenu English School (Play Group–12th) and the Medical Academy for NEET, JEE, CUET, JET and Foundation courses.',
  },
  {
    q: 'When do new batches start?',
    a: 'The NEET 2027 Dropper Batch starts in June 2026. RAS Foundation and Arts batches begin with the 2027 academic session.',
  },
  {
    q: 'Are hostels available?',
    a: 'Yes. Kamdhenu Adarsh Chhatravas offers separate, secure hostels for boys and girls with night study camps.',
  },
  {
    q: 'Where is the campus?',
    a: `Our campus is on ${site.address}. Call us at ${site.phoneDisplay}.`,
  },
]

export function ChatWidget() {
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState<number | null>(null)

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3">
      {open && (
        <div
          id="chat-panel"
          role="dialog"
          aria-label="Kamdhenu assistant"
          className="w-[calc(100vw-2.5rem)] max-w-sm overflow-hidden rounded-3xl border border-border bg-card shadow-2xl animate-in fade-in slide-in-from-bottom-4"
        >
          <div className="flex items-center gap-3 bg-primary p-4 text-primary-foreground">
            <span className="flex size-10 items-center justify-center rounded-full bg-accent text-primary">
              <Bot className="size-5" aria-hidden="true" />
            </span>
            <div>
              <p className="font-semibold">Kamdhenu Assistant</p>
              <p className="text-xs text-primary-foreground/70">Typically replies instantly</p>
            </div>
          </div>
          <div className="flex max-h-80 flex-col gap-3 overflow-y-auto p-4" aria-live="polite">
            <p className="w-fit max-w-[85%] rounded-2xl rounded-tl-sm bg-secondary px-4 py-2.5 text-sm text-foreground">
              Namaste! How can I help you today?
            </p>
            {active !== null && (
              <>
                <p className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-tr-sm bg-primary px-4 py-2.5 text-sm text-primary-foreground">
                  {faqs[active].q}
                </p>
                <p className="w-fit max-w-[85%] rounded-2xl rounded-tl-sm bg-secondary px-4 py-2.5 text-sm text-foreground">
                  {faqs[active].a}
                </p>
              </>
            )}
            <div className="flex flex-wrap gap-2 pt-1">
              {faqs.map((f, i) => (
                <button
                  key={f.q}
                  type="button"
                  onClick={() => setActive(i)}
                  className="rounded-full border border-primary/20 px-3 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
                >
                  {f.q}
                </button>
              ))}
            </div>
          </div>
          <div className="border-t border-border p-3">
            <a
              href={site.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 rounded-full bg-accent px-4 py-2.5 text-sm font-semibold text-primary"
            >
              <MessageCircle className="size-4" aria-hidden="true" />
              Talk to Human (WhatsApp)
            </a>
          </div>
        </div>
      )}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-controls="chat-panel"
        aria-label={open ? 'Close chat assistant' : 'Open chat assistant'}
        className="flex size-14 items-center justify-center rounded-full bg-primary text-accent shadow-xl shadow-primary/30 ring-4 ring-accent/30 transition-transform hover:scale-105"
      >
        {open ? <X className="size-6" /> : <Bot className="size-6" />}
      </button>
    </div>
  )
}
