import Image from 'next/image'
import { ArrowRight, Award, Users, CalendarDays } from 'lucide-react'

const stats = [
  { icon: CalendarDays, value: '12+', label: 'Years of Trust' },
  { icon: Award, value: '90%+', label: 'Board Results' },
  { icon: Users, value: '5000+', label: 'Students Mentored' },
]

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="relative isolate overflow-hidden">
      <Image
        src="/images/campus-hero.png"
        alt="Kamdhenu campus building at golden hour"
        fill
        priority
        sizes="100vw"
        className="-z-20 object-cover"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-primary/95 via-primary/80 to-primary/30" />

      <div className="mx-auto flex min-h-[640px] max-w-7xl flex-col justify-center px-4 py-20 sm:px-6 lg:min-h-[720px]">
        <div className="max-w-2xl text-primary-foreground">
          <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-4 py-1.5 text-xs font-medium text-accent sm:text-sm">
            शिक्षा व संस्कारों की दिव्य कर्मस्थली
          </p>
          <h1 id="hero-title" className="text-4xl font-bold leading-tight sm:text-5xl lg:text-6xl">
            Shaping a Brighter Future <span className="text-accent italic">with Knowledge &amp; Values</span>
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-primary-foreground/85 sm:text-lg">
            {"Western Rajasthan's most trusted institute for Science, Medical, and Arts. Dedicated to Science | Medical | Engineering | Agriculture."}
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <a
              href="#institutions"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-accent px-7 py-3.5 font-semibold text-accent-foreground shadow-lg shadow-black/20 transition-all hover:-translate-y-0.5 hover:shadow-xl"
            >
              Explore Our Campus
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
            </a>
            <a
              href="#batches"
              className="inline-flex items-center justify-center rounded-full border border-primary-foreground/40 px-7 py-3.5 font-semibold text-primary-foreground transition-colors hover:bg-primary-foreground/10"
            >
              Apply Now
            </a>
          </div>
        </div>

        <dl className="mt-14 grid max-w-2xl grid-cols-3 gap-3 sm:gap-5">
          {stats.map((s) => (
            <div
              key={s.label}
              className="rounded-2xl border border-primary-foreground/15 bg-primary-foreground/10 p-4 text-primary-foreground backdrop-blur-sm sm:p-5"
            >
              <s.icon className="mb-2 size-5 text-accent" aria-hidden="true" />
              <dt className="sr-only">{s.label}</dt>
              <dd className="font-serif text-2xl font-bold sm:text-3xl">{s.value}</dd>
              <dd className="text-xs text-primary-foreground/75 sm:text-sm">{s.label}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  )
}
