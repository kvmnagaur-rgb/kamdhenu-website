import { CalendarDays, Clock, Landmark, Stethoscope, BookOpen, ArrowRight } from 'lucide-react'
import { SectionHeading } from './section-heading'
import { site } from '@/lib/site'

const batches = [
  {
    icon: Landmark,
    tag: 'Civil Services',
    title: 'RAS Foundation Batch',
    desc: 'Expert guidance for a successful career in civil services, with Rajasthan GK, current affairs and answer-writing practice.',
    start: 'April 2027',
    duration: '12 months',
  },
  {
    icon: Stethoscope,
    tag: 'Medical',
    title: 'NEET 2027 Dropper Batch',
    desc: 'Intensive, result-focused programme for repeaters with daily practice papers, full-length mocks and personal mentoring.',
    start: 'June 2026',
    duration: '11 months',
  },
  {
    icon: BookOpen,
    tag: 'Humanities',
    title: 'Arts Batch',
    desc: 'A strong humanities foundation in History, Political Science and Geography for school and competitive exam success.',
    start: 'April 2027',
    duration: 'Academic session',
  },
]

export function UpcomingBatches() {
  return (
    <section id="batches" aria-labelledby="batches-title" className="bg-primary px-4 py-24 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          id="batches-title"
          tone="dark"
          eyebrow="Upcoming Batches"
          title="Starting in 2027"
          description="Get ready for our exclusive RAS Foundation and Arts Batch starting from the new academic session in 2027. Expert guidance for a successful career in civil services and humanities."
        />
        <div className="grid gap-6 md:grid-cols-3">
          {batches.map((b) => (
            <article
              key={b.title}
              className="flex flex-col rounded-3xl border border-primary-foreground/10 bg-primary-foreground/[0.06] p-7 text-primary-foreground transition-all hover:-translate-y-1 hover:border-accent/50 hover:bg-primary-foreground/10"
            >
              <div className="flex items-center justify-between">
                <span className="flex size-12 items-center justify-center rounded-xl bg-accent text-primary">
                  <b.icon className="size-5" aria-hidden="true" />
                </span>
                <span className="rounded-full bg-accent/15 px-3 py-1 text-xs font-medium text-accent">{b.tag}</span>
              </div>
              <h3 className="mt-6 text-2xl font-bold">{b.title}</h3>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-primary-foreground/75">{b.desc}</p>
              <dl className="mt-6 grid grid-cols-2 gap-3 border-t border-primary-foreground/10 pt-5 text-sm">
                <div className="flex items-center gap-2">
                  <CalendarDays className="size-4 text-accent" aria-hidden="true" />
                  <dt className="sr-only">Starts</dt>
                  <dd>{b.start}</dd>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="size-4 text-accent" aria-hidden="true" />
                  <dt className="sr-only">Duration</dt>
                  <dd>{b.duration}</dd>
                </div>
              </dl>
              <a
                href={`${site.whatsapp}?text=${encodeURIComponent(`Hello, I want to enroll in the ${b.title}.`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="group mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-primary transition-all hover:shadow-lg hover:shadow-accent/20"
              >
                Enroll Now
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
