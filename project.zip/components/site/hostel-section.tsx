import Image from 'next/image'
import { Moon, ShieldCheck, Users, BedDouble } from 'lucide-react'
import { SectionHeading } from './section-heading'

const hostels = ['KVM', 'BRS', 'SURBHI', 'NANDINI', 'MDS', 'KBH', 'White House']

const highlights = [
  { icon: Users, title: 'Separate Boys & Girls Hostels', text: 'Dedicated residences with caring wardens.' },
  { icon: Moon, title: 'Night Study Camps', text: 'Supervised evening sessions with mentors.' },
  { icon: ShieldCheck, title: 'Indian Culture & Lifestyle', text: 'Prayer, yoga and sanskar-based routine.' },
]

export function HostelSection() {
  return (
    <section id="hostel" aria-labelledby="hostel-title" className="px-4 py-24 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <SectionHeading
              id="hostel-title"
              align="left"
              eyebrow="Gurukul System"
              title="Kamdhenu Adarsh Chhatravas"
              description="Separate hostels for Boys and Girls based on Indian culture and lifestyle, with special night study camps so every student studies in a disciplined, homely and focused environment."
            />
            <ul className="-mt-4 flex flex-col gap-4">
              {highlights.map((h) => (
                <li key={h.title} className="flex items-start gap-4 rounded-2xl border border-border bg-card p-4 shadow-sm">
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary text-accent">
                    <h.icon className="size-5" aria-hidden="true" />
                  </span>
                  <div>
                    <h3 className="font-sans text-base font-semibold text-primary">{h.title}</h3>
                    <p className="text-sm text-muted-foreground">{h.text}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="relative aspect-[4/3] overflow-hidden rounded-3xl shadow-xl">
            <Image
              src="/images/hostel.png"
              alt="Kamdhenu hostel courtyard with students studying"
              fill
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover"
            />
          </div>
        </div>

        <div className="mt-16">
          <h3 className="mb-6 text-center font-sans text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">
            Our Hostels
          </h3>
          <ul className="grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-7">
            {hostels.map((h) => (
              <li
                key={h}
                className="group flex flex-col items-center gap-2 rounded-2xl border border-border bg-card px-4 py-6 text-center shadow-sm transition-all hover:-translate-y-1 hover:border-primary hover:bg-primary"
              >
                <BedDouble className="size-6 text-primary transition-colors group-hover:text-accent" aria-hidden="true" />
                <span className="font-serif text-lg font-bold text-primary transition-colors group-hover:text-primary-foreground">
                  {h}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
