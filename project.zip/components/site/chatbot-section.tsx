import { Bot, MessageCircle, Sparkles } from 'lucide-react'
import { site } from '@/lib/site'

export function ChatbotSection() {
  return (
    <section id="chatbot" aria-labelledby="chatbot-title" className="px-4 pb-24 sm:px-6">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-8 rounded-3xl bg-primary p-8 text-center text-primary-foreground shadow-xl shadow-primary/20 sm:p-12 md:flex-row md:text-left">
        <span className="flex size-20 shrink-0 items-center justify-center rounded-3xl bg-accent text-primary shadow-lg">
          <Bot className="size-10" aria-hidden="true" />
        </span>
        <div className="flex-1">
          <p className="mb-2 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-accent">
            <Sparkles className="size-3.5" aria-hidden="true" />
            AI Assistant
          </p>
          <h2 id="chatbot-title" className="text-2xl font-bold sm:text-3xl">
            Have questions about admissions, fees or hostels?
          </h2>
          <p className="mt-2 text-primary-foreground/80">
            Ask our AI Chatbot anytime, or speak directly with our admissions team on WhatsApp.
          </p>
        </div>
        <div className="flex w-full flex-col gap-3 sm:w-auto">
          <a
            href={site.whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 rounded-full bg-accent px-6 py-3.5 text-sm font-semibold text-primary transition-all hover:shadow-lg hover:shadow-accent/20"
          >
            <MessageCircle className="size-4" aria-hidden="true" />
            Talk to Human (WhatsApp)
          </a>
        </div>
      </div>
    </section>
  )
}
