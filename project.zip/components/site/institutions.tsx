import { Check, FlaskConical, School, Stethoscope, ArrowRight } from 'lucide-react'
import { SectionHeading } from './section-heading'

const institutions = [
  {
    icon: FlaskConical,
    name: 'Kamdhenu Science School',
    level: 'Class 6th to 12th',
    features: ['90%+ board results', 'Expert-designed study modules', 'DTS, Minor & Major test series', 'Hindi & English medium'],
  },
  {
    icon: School,
    name: 'Kamdhenu English School',
    level: 'Play Group to 12th',
    features: ['Smart digital classrooms', 'Activity-based learning', 'High-security campus', 'Value-based education'],
    featured: true,
  },
  {
    icon: Stethoscope,
    name: 'Kamdhenu Medical Academy',
    level: 'For 11th & 12th passed students',
    features: ['NEET & JEE preparation', 'CUET & JET coaching', 'Foundation & Pre-Foundation', 'Doubt-clearing sessions'],
  },
]

export function Institutions() {
  return (
    <section id="institutions" aria-labelledby="institutions-title" className="px-4 py-24 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeading
          id="institutions-title"
          eyebrow="Our Institutions"
          title="One Family, Many Paths to Excellence"
          description="From the first day of Play Group to the final NEET attempt, Kamdhenu guides every learner with dedicated schools, a medical academy and caring mentors."
        />
        <div className="grid gap-6 md:grid-cols-3">
          {institutions.map((inst) => (
            <article
              key={inst.name}
              className={`group flex flex-col rounded-3xl border p-8 shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl ${
                inst.featured
                  ? 'border-primary bg-primary text-primary-foreground shadow-primary/20'
                  : 'border-border bg-card hover:shadow-primary/10'
              }`}
            >
              <span
                className={`mb-6 flex size-14 items-center justify-center rounded-2xl ${
                  inst.featured ? 'bg-accent text-primary' : 'bg-secondary text-primary'
                }`}
              >
                <inst.icon className="size-6" aria-hidden="true" />
              </span>
              <h3 className={`text-2xl font-bold ${inst.featured ? '' : 'text-primary'}`}>{inst.name}</h3>
              <p className={`mt-1 text-sm font-medium ${inst.featured ? 'text-accent' : 'text-muted-foreground'}`}>
                {inst.level}
              </p>
              <ul className="mt-6 flex flex-1 flex-col gap-3">
                {inst.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm">
                    <Check
                      className={`mt-0.5 size-4 shrink-0 ${inst.featured ? 'text-accent' : 'text-primary'}`}
                      aria-hidden="true"
                    />
                    <span className={inst.featured ? 'text-primary-foreground/90' : 'text-foreground/80'}>{f}</span>
                  </li>
                ))}
              </ul>
              <a
                href="#contact"
                className={`mt-8 inline-flex items-center gap-2 text-sm font-semibold ${
                  inst.featured ? 'text-accent' : 'text-primary'
                }`}
              >
                Learn more
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
