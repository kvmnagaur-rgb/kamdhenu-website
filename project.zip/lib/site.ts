export const site = {
  name: 'Kamdhenu Education Institute',
  shortName: 'Kamdhenu Nagaur',
  phone: '7976152923',
  phoneDisplay: '+91 79761 52923',
  email: 'info@kamdhenunagaur.com',
  address: 'Gurla Road, Nagaur, Rajasthan 341001',
  website: 'kamdhenunagaur.com',
  whatsapp: 'https://wa.me/917976152923',
}

export const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About Us', href: '#about' },
  { label: 'Academics', href: '#institutions' },
  { label: 'Hostel', href: '#hostel' },
  { label: 'Admission', href: '#batches' },
  { label: 'Contact', href: '#contact' },
]
