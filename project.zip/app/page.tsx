import { TopBar } from '@/components/site/top-bar'
import { SiteHeader } from '@/components/site/site-header'
import { Hero } from '@/components/site/hero'
import { QuickLinks } from '@/components/site/quick-links'
import { Institutions } from '@/components/site/institutions'
import { UpcomingBatches } from '@/components/site/upcoming-batches'
import { AcademicExcellence } from '@/components/site/academic-excellence'
import { DirectorMessage } from '@/components/site/director-message'
import { HostelSection } from '@/components/site/hostel-section'
import { ChatbotSection } from '@/components/site/chatbot-section'
import { SiteFooter } from '@/components/site/site-footer'
import { ChatWidget } from '@/components/site/chat-widget'

export default function Page() {
  return (
    <>
      <TopBar />
      <SiteHeader />
      <main id="home">
        <Hero />
        <QuickLinks />
        <Institutions />
        <UpcomingBatches />
        <AcademicExcellence />
        <DirectorMessage />
        <HostelSection />
        <ChatbotSection />
      </main>
      <SiteFooter />
      <ChatWidget />
    </>
  )
}
